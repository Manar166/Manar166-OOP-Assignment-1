﻿using HotelReservationSystem._ٍServices;
using HotelReservationSystem.Enums;
using HotelReservationSystem.Models;
using HotelReservationSystem.Reposatories;
using HotelReservationSystem.Models;

namespace HotelReservationSystem
{
    public class Program
    {
        public static List<Room> rooms = new List<Room>();

        public static List<Guest> Guests = new List<Guest>();

        public static List<Reservation> Reservations = new List<Reservation>();

        public static RoomRepository roomRepository = new RoomRepository();
        public static GuestRepository guestRepository = new GuestRepository();
        public static ReservationRepository reservationRepository = new ReservationRepository();

        //ReservationRepository reservationRepository = new ReservationRepository(roomRepository ,new GuestRepository());
        public static GuestService guestService = new GuestService();
        public static RoomService roomService = new RoomService(roomRepository);
        public static ReservationService reservationService = new ReservationService();
        static void Main(string[] args)
        {
            SeedData();
            //roomService.AddRoom();
            roomService.DisplayAllRooms();
            //  roomService.FindRoomByNumber();

            //guestService.AddGuest();
            guestService.DisplayAllGuests();

            reservationService.CreateReservation();
            reservationService.DisplayAllReservations();
             reservationService.FindReservationByGuestId();
            //guestService.DisplayGuestReservations();


        }

        private static void SeedData()
        {
            // 🎯 إضافة غرف تجريبية
            roomRepository.AddRoom(101, RoomType.Single, 100m);
            roomRepository.AddRoom(102, RoomType.Double, 150m);
            roomRepository.AddRoom(201, RoomType.Suite, 300m);

            // 🎯 إضافة نزلاء تجريبيين (مع التأكد من وجود Constructor مناسب لكلاس Guest)
            guestRepository.AddGuest(1, "Ahmed Hassan",  "01012345678");
            guestRepository.AddGuest(2, "Sara Ali",  "01198765432");

            // 🎯 إضافة حجز تجريبي للـ Testing
            //reservationService.CreateReservation(
            //   I: 1,
            //    checkInTime: DateTime.Now.AddDays(1),
            //    checkOutTime: DateTime.Now.AddDays(4),
            //    roomNumber: 101,
            //    guestId: 1
            //);

            Console.WriteLine("✅ Initial Seed Data Added Successfully!\n");
        }
    }
}
